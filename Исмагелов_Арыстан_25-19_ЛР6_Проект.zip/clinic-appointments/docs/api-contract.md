# UC-01 Запись пациента
Проект: GET /api/specialties/, GET /api/doctors/?specialty_id=...,
GET /api/available-slots/?doctor_id=...&date=...,
POST /api/bookings/ {slot_id, channel} + Idempotency-Key,
GET /api/booking-requests/{key}/, GET /api/bookings/{id}/ticket/.
4а: 200 items=[]; 8а: 409 SLOT_BUSY; 8б: 409 PATIENT_OVERLAP.
8в: сеть/504 шлюза; запрос результата по прежнему ключу, затем безопасный повтор.
1а: регистратор передаёт ID пациента после проверки личности и прав.

Реализованы GET /api/doctors/ без фильтра и GET /api/slots/?doctor_id=doctor-1.
Слоты опубликованы, но не проверены на занятость: постоянных записей пока нет.
GET slots: 400 DOCTOR_REQUIRED, 404 DOCTOR_NOT_FOUND.
Успех: 200, items с id, doctor_id, start, end, duration_min;
timezone=Asia/Almaty, window_days=14. Короткие ID — только заглушка.
Полный контракт запросов, ответов и ограничений приведён в отчёте ЛР №6.
