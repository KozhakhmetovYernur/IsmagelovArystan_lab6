from datetime import datetime, timedelta
from unittest.mock import patch

from django.test import SimpleTestCase

from schedule.repositories import TZ
from schedule.services import duration_minutes, is_bookable_start, published_slots

NOW = datetime(2026, 11, 2, 9, 0, tzinfo=TZ)


class RuleTests(SimpleTestCase):
    def test_duration(self):
        self.assertEqual(duration_minutes(NOW, NOW + timedelta(minutes=20)), 20)

    def test_invalid_end(self):
        with self.assertRaises(ValueError):
            duration_minutes(NOW, NOW)

    def test_fractional_minute(self):
        with self.assertRaises(ValueError):
            duration_minutes(NOW, NOW + timedelta(seconds=61))

    def test_past_forbidden(self):
        self.assertFalse(is_bookable_start(NOW - timedelta(minutes=1), NOW))

    def test_last_day_included(self):
        self.assertTrue(is_bookable_start(NOW + timedelta(days=13, hours=1), NOW))

    def test_fourteenth_day_excluded(self):
        self.assertFalse(is_bookable_start(NOW + timedelta(days=14), NOW))

    def test_unpublished_slot_hidden(self):
        slot = {
            "id": "s",
            "doctor_id": "doctor-1",
            "published": False,
            "start": NOW + timedelta(hours=1),
            "end": NOW + timedelta(hours=2),
        }
        with patch("schedule.repositories.list_slots", return_value=[slot]):
            self.assertEqual(published_slots("doctor-1", NOW), [])


class HttpTests(SimpleTestCase):
    def test_screen_and_api(self):
        screen, response = self.client.get("/"), self.client.get("/api/doctors/")
        self.assertEqual(response.status_code, 200)
        for doctor in response.json()["items"]:
            self.assertContains(screen, doctor["name"])
            self.assertEqual(doctor["duration_min"], 20)

    def test_unknown_doctor(self):
        response = self.client.get("/api/slots/?doctor_id=absent")
        self.assertEqual(response.status_code, 404)

    def test_slots_api(self):
        response = self.client.get("/api/slots/?doctor_id=doctor-1")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["window_days"], 14)
        self.assertEqual(response.json()["items"][0]["duration_min"], 20)
