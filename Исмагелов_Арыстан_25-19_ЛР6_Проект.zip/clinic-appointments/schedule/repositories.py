"""Слой данных: вымышленные врачи и слоты вместо моделей БД."""

from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo

TZ = ZoneInfo("Asia/Almaty")


def list_doctors():
    return [
        {
            "id": "doctor-1",
            "name": "Иванова Анна Сергеевна",
            "specialty": "Терапия",
            "cabinet": "204",
        },
        {
            "id": "doctor-2",
            "name": "Омаров Данияр Ерланович",
            "specialty": "Терапия",
            "cabinet": "208",
        },
    ]


def list_slots():
    tomorrow = datetime.now(TZ).date() + timedelta(days=1)
    start = datetime.combine(tomorrow, time(10, 0), TZ)
    return [
        {
            "id": "slot-1",
            "doctor_id": "doctor-1",
            "start": start,
            "end": start + timedelta(minutes=20),
            "published": True,
        },
        {
            "id": "slot-2",
            "doctor_id": "doctor-2",
            "start": start,
            "end": start + timedelta(minutes=20),
            "published": True,
        },
    ]
