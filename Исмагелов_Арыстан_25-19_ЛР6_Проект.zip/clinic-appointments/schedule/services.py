"""Слой логики: БП-01 (14 дней) и БП-04 (длительность)."""

from datetime import datetime, timedelta

from . import repositories
from .repositories import TZ


def duration_minutes(start, end):
    seconds = (end - start).total_seconds()
    if seconds <= 0 or seconds % 60:
        raise ValueError("Окончание должно быть позже начала на целое число минут")
    return int(seconds // 60)


def is_bookable_start(start, now):
    local_start, local_now = start.astimezone(TZ), now.astimezone(TZ)
    return (
        local_start > local_now
        and local_now.date() <= local_start.date() <= local_now.date() + timedelta(days=13)
    )


def published_slots(doctor_id, now=None):
    now = now or datetime.now(TZ)
    return [
        {
            "id": s["id"],
            "doctor_id": s["doctor_id"],
            "start": s["start"].isoformat(),
            "end": s["end"].isoformat(),
            "duration_min": duration_minutes(s["start"], s["end"]),
        }
        for s in repositories.list_slots()
        if s["doctor_id"] == doctor_id and s["published"] and is_bookable_start(s["start"], now)
    ]


def list_doctors(now=None):
    result = []
    for doctor in repositories.list_doctors():
        slots = published_slots(doctor["id"], now)
        result.append(
            {
                **doctor,
                "duration_min": slots[0]["duration_min"] if slots else None,
                "next_start": slots[0]["start"] if slots else None,
            }
        )
    return result
