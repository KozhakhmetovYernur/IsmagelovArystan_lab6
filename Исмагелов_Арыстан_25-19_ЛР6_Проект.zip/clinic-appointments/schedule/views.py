from django.http import JsonResponse
from django.shortcuts import render

from . import services


def doctor_screen(request):
    return render(request, "schedule/doctors.html", {"doctors": services.list_doctors()})


def doctors_api(request):
    return JsonResponse(
        {"items": services.list_doctors()}, json_dumps_params={"ensure_ascii": False}
    )


def slots_api(request):
    doctor_id = request.GET.get("doctor_id")
    if not doctor_id:
        return JsonResponse({"error": "DOCTOR_REQUIRED", "message": "Выберите врача"}, status=400)
    if not any(d["id"] == doctor_id for d in services.list_doctors()):
        return JsonResponse({"error": "DOCTOR_NOT_FOUND"}, status=404)
    return JsonResponse(
        {"items": services.published_slots(doctor_id), "timezone": "Asia/Almaty", "window_days": 14}
    )
