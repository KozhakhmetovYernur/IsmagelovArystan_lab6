"""Заготовка идентификации и согласий. Настоящего входа в скелете нет."""

ROLES = ("patient", "registrar", "doctor", "administrator")
